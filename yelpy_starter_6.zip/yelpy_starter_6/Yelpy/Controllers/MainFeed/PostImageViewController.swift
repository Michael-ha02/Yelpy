//
//  PostImageViewController.swift
//  Yelpy
//
//  Created by Michael Ha on 3/26/22.
//  Copyright © 2020 memo. All rights reserved.
//

import UIKit

<<<<<<< HEAD

// MARK: LAB 6 TODO: Create Protocol for PostImageViewControllerDelegate
protocol PostImageViewControllerDelegate: AnyObject {
=======
// MARK: LAB 6 TODO: Create protocol for PostImageViewControllerDelegate
protocol PostImageViewControllerDelegate: class  {
>>>>>>> fe2957b972d5f23dd64925334d1230b059b7bcfe
    func imageSelected(controller: PostImageViewController, image: UIImage)
}

class PostImageViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var selectedImageView: UIImageView!
    
<<<<<<< HEAD
    // MARK: LAB 6 TODO: Add delegate for the protocol you created
=======
    // MARK: LAB 6 TODO: Add delegate for the protocol  you created
>>>>>>> fe2957b972d5f23dd64925334d1230b059b7bcfe
    weak var delegate: PostImageViewControllerDelegate!

    override func viewDidLoad() {
        super.viewDidLoad()

        createImagePicker()
        navigationController?.navigationBar.isHidden = true
        
    }

    
    @IBAction func onFinishPosting(_ sender: Any) {
        performSegue(withIdentifier: "unwindToDetail", sender: self)
        
        // MARK: LAB 6 TODO: Pass image through protocol method
        delegate.imageSelected(controller: self, image: self.selectedImageView.image!)
    }
    
    
    // Unwind back to Restaurant Detail after uploading image
    @IBAction func onFinishPosting(_ sender: Any) {
        performSegue(withIdentifier: "unwindToDetail", sender: self)
        
        // MARK: LAB 6 TODO: Pass image through protocol method
        delegate.imageSelected(controller: self, image: self.selectedImageView.image!)
    }
    
    
    // MARK: LAB 6 TODO: ImagePicker Delegate Methods
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let originalImage = info[.originalImage] as! UIImage

        self.selectedImageView.image = originalImage
        
        dismiss(animated: true, completion: nil)
    }

    
    // MARK: Create Image Picker
    func createImagePicker() {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            print("Camera is available 📸")
            imagePicker.sourceType = .camera
        } else {
            print("Camera 🚫 available so we will use photo library instead")
            imagePicker.sourceType = .photoLibrary
        }
        self.present(imagePicker, animated: true, completion: nil)
    }
    
<<<<<<< HEAD
=======
    // MARK: ImagePicker Delegate Methods
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let originalImage = info[.originalImage] as! UIImage
        //let editedImage = info[.editedImage] as! UIImage
        

        self.selectedImageView.image = originalImage
        
        print("image dismissed")
        dismiss(animated: true, completion: nil)
    }
    
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
>>>>>>> fe2957b972d5f23dd64925334d1230b059b7bcfe

}
