//
//  stars.swift
//  Yelpy
//
//  Created by Memo on 5/27/20.
//  Copyright © 2020 memo. All rights reserved.
//

import Foundation
